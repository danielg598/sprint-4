package com.linapalomo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.linapalomo.model.Persona;
import com.linapalomo.repositorio.PersonaRepositorio;

@RestController
@RequestMapping("/api") //las app modernas usan mvc. la vista es lo visual con lo que el user interactúa.
//los controladores reciben las solicitudes del user. El controlador se comunica con la capa del modelo.

public class PersonaController {
	
	@Autowired
	private PersonaRepositorio personaRepositorio;

	@GetMapping("/personas")
	public List<Persona> buscarPersonas(){
		return personaRepositorio.findAll();
		
	}
	
	@GetMapping("/persona/{name}")
	public List<Persona> findByName(@PathVariable("name") String name){
		return personaRepositorio.findByName(name);
		
	}
	
	@PostMapping("/persona")
	public Persona createPersona(@RequestBody Persona persona){
		return personaRepositorio.save(persona);
	}
	
	@DeleteMapping("/persona/{id}")
	public void borrarPersona(@PathVariable("id") Long id) {
	personaRepositorio.deleteById(id);
	}
}
