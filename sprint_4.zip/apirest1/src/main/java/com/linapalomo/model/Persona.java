package com.linapalomo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class Persona {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY ) //para generar automáticamente la tabla
	private Long id;
	private String name, user_name;
	private Date date_register;
	
	public Persona() {
		
	}
	
	public Persona(Long id, String name, String user_name, Date date_register) {
		
		this.id = id;
		this.name = name;
		this.user_name = user_name;
		this.date_register = date_register;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public Date getDate_register() {
		return date_register;
	}

	public void setDate_register(Date date_register) {
		this.date_register = date_register;
	}

	@Override
	public String toString() {
		return "Persona [id=" + id + ", name=" + name + ", user_name=" + user_name + ", date_register=" + date_register
				+ "]";
	}

}
