package com.linapalomo.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.linapalomo.model.Persona;

public interface PersonaRepositorio extends JpaRepository<Persona, Long> {
	List<Persona> findByName(@Param("name") String name ); // se crea una lista de tipo persona y el metodo es buscar por nombre con el parametro name

	
	

}
